package poly.edu.model;

public class OrderDetailDto {

}
