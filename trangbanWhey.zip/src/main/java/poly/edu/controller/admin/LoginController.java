package poly.edu.controller.admin;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionIdListener;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import poly.edu.domain.Account;
import poly.edu.model.AccountDto;
import poly.edu.model.AdminLoginDto;
import poly.edu.sevice.AccountService;

@Controller
public class LoginController {
     @Autowired
     private AccountService accountService;
     
     @Autowired
     private HttpSession session;
     
     @GetMapping("")
     public String login(Model model) {
    	 model.addAttribute("account", new AdminLoginDto() );
    	
    	 return "admin/accounts/login";
     }
     
   
    @GetMapping("dangky")
    public String add(Model model) {
 	   model.addAttribute("account", new AccountDto());
 	   return "admin/accounts/addOrEdit";
    }
     
     @GetMapping("login")
     public ModelAndView ulogin(ModelMap model,
    		        @Valid  @ModelAttribute("account") AdminLoginDto dto,
    		        BindingResult result) {
    	 if (result.hasErrors()) {
			return new ModelAndView("admin/accounts/login", model);
		}
    	 Account account = accountService.login(dto.getUsername(), dto.getPassword());
    	 
    	 if(account == null) {
    		 model.addAttribute("message", "INvalid username or password");
    		 return new ModelAndView("admin/accounts/login", model);
    	 }
    	 session.setAttribute("username", account.getUsername());
    	 Object ruri = session.getAttribute("redirect-uri");//Kiểm tra đăng nhập chưa
    	 if (ruri != null) {
    		 session.removeAttribute("redirect-uri");
			return new ModelAndView("redirect: " + ruri);
		}
    	 
    	 
    	 return new ModelAndView("admin/products/homesite", model);
     }
     
     @GetMapping("admin/login")
     public ModelAndView adminlogin(ModelMap model,
    		        @Valid  @ModelAttribute("account") AdminLoginDto dto,
    		        BindingResult result) {
    	 if (result.hasErrors()) {
			return new ModelAndView("admin/accounts/adminlogin", model);
		}
    	 Account account = accountService.login(dto.getUsername(), dto.getPassword());
    	 
    	 if(account == null) {
    		 model.addAttribute("message", "INvalid username or password");
    		 return new ModelAndView("admin/accounts/adminlogin", model);
    	 }
    	 session.setAttribute("username", account.getUsername());
    	 Object ruri = session.getAttribute("redirect-uri");//Kiểm tra đăng nhập chưa
    	 if (ruri != null) {
    		 session.removeAttribute("redirect-uri");
			return new ModelAndView("redirect: " + ruri);
		}
    	 
    	 
    	 return new ModelAndView("admin/products/homeadmin", model);
     }
}
